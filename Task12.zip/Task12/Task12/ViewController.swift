//
//  ViewController.swift
//  Task12
//
//  Created by Tushar Ingale on 27/04/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var btn_Task: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.btn_Task.addTarget(self, action: #selector(btn_TaskIsClicked), for: UIControl.Event.touchUpInside)
        
    }
    
}

extension ViewController {
    
    @objc func btn_TaskIsClicked(){
        
        let movieListViewController = MovieListViewController(nibName: "MovieListViewController", bundle: nil)
        self.navigationController?.pushViewController(movieListViewController, animated: true)
        
    }
}




//
//  DetailsMovieViewController.swift
//  Task12
//
//  Created by Mahesh Gaykar on 27/04/22.
//

import UIKit

class DetailsMovieViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

       
    }



}

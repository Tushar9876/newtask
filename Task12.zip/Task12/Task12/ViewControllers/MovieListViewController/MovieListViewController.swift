//
//  MovieListViewController.swift
//  Task12
//
//  Created by Tushar Ingale on 27/04/22.
//

import UIKit

class MovieListViewController: UIViewController {


    @IBOutlet weak var tableView_MovieList: UITableView!
    @IBOutlet weak var searcBarMovieList: UISearchBar!
    
    var arrayOfMovie:[MoviewModel] = [MoviewModel]()
    var networkLayer = NetworkLayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tableView_MovieList.register(UINib(nibName: "MovieListTableViewCell", bundle: nil), forCellReuseIdentifier: "movieListTableViewCell")
        self.tableView_MovieList.dataSource = self
        self.tableView_MovieList.delegate = self
        self.tableView_MovieList.separatorInset = .zero
        
        networkLayer.parseApi(url: EndPoint.urlStringOfstoplight)
        networkLayer.delegateDataTransfer = self
    }
}

extension MovieListViewController : UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return arrayOfMovie.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "movieListTableViewCell", for: indexPath) as? MovieListTableViewCell else {
            return UITableViewCell()
        }
        cell.lbl_Name.text = arrayOfMovie[indexPath.row].originalTitle
        cell.lbl_Ratings.text = String(arrayOfMovie[indexPath.row].voteAverage)
        cell.configureCell(index:indexPath.row,movie:arrayOfMovie[indexPath.row])
        
        return cell
    }
    
}


extension MovieListViewController : UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        let movieDetailsViewController = MovieDetailsViewController(nibName: "MovieDetailsViewController", bundle: nil)
        movieDetailsViewController.movieDetails = arrayOfMovie[indexPath.row]
        self.navigationController?.pushViewController(movieDetailsViewController, animated: true)
    }
}


extension MovieListViewController:DataTransfer {
    
    func sendDataToVC(array: [MoviewModel]) {
        
        self.arrayOfMovie = array
        self.tableView_MovieList.reloadData()
      //  print("ViewController_array",array)
    }
    
}

//
//  MovieListTableViewCell.swift
//  Task12
//
//  Created byTushar Ingale on 27/04/22.
//

import UIKit

class MovieListTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var img_Movie: UIImageView!
    @IBOutlet weak var lbl_Name: UILabel!
    @IBOutlet weak var lbl_Ratings: UILabel!
    @IBOutlet weak var img_Star: UIImageView!
    @IBOutlet weak var img_Poster: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.lbl_Name.numberOfLines = 0
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func configureCell(index:Int,movie:MoviewModel){
        
        guard let urlString = URL(string: movie.posterPath) else {return}
        
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: urlString){
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self?.img_Poster.image = image
                    }
                }
            }
        }

    }
    
}

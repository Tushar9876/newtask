//
//  MovieDetailsViewController.swift
//  Task12
//
//  Created by Tushar Ingale on 28/04/22.
//

import UIKit

class MovieDetailsViewController: UIViewController {
    
    @IBOutlet weak var img_Movie: UIImageView!
    @IBOutlet weak var lbl_title: UILabel!
    @IBOutlet weak var lbl_ReleaseDate: UILabel!
    @IBOutlet weak var lbl_lang: UILabel!
    @IBOutlet weak var lbl_Ratings: UILabel!
    @IBOutlet weak var lbl_Overview: UILabel!
    
    var movieDetails = MoviewModel()
    var imageMovie = UIImage()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = movieDetails.originalTitle
        
        self.lbl_Overview.numberOfLines = 0
        self.img_Movie.image = imageMovie
        
        guard let urlString = URL(string: movieDetails.posterPath) else {return}
        
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: urlString){
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self?.img_Movie.image = image
                    }
                }
            }
        }

        let voteAverage = "Vote Average : \(movieDetails.voteAverage)"
        let attributedQuotevoteAverage = NSMutableAttributedString(string: voteAverage)
        let attributesvoteAverage: [NSAttributedString.Key: Any] = [NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 17)]
        attributedQuotevoteAverage.addAttributes(attributesvoteAverage, range: NSRange(location: 0, length: 11))
        self.lbl_Ratings.attributedText = attributedQuotevoteAverage
        
        let releaseDate = "Release Date : \(movieDetails.releaseDate)"
        let attributedQuotereleaseDate = NSMutableAttributedString(string: releaseDate)
        let attributesattributedQuotereleaseDate: [NSAttributedString.Key: Any] = [NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 17)]
        attributedQuotereleaseDate.addAttributes(attributesattributedQuotereleaseDate, range: NSRange(location: 0, length: 14))
        self.lbl_ReleaseDate.attributedText = attributedQuotereleaseDate
        
        self.lbl_title.text = movieDetails.originalTitle
        
        let originalLanguage = "original Language : \(movieDetails.originalLanguage)"
        let attributedQuotoriginalLanguage = NSMutableAttributedString(string: originalLanguage)
        let attributesattributed: [NSAttributedString.Key: Any] = [NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 17)]
        attributedQuotoriginalLanguage.addAttributes(attributesattributed, range: NSRange(location: 0, length: 16))
        self.lbl_lang.attributedText = attributedQuotoriginalLanguage
        
        let overview = "overview \n \n  \(movieDetails.overview)"
        let attributedQuotoverview = NSMutableAttributedString(string: overview)
        let attributesattributedoverview: [NSAttributedString.Key: Any] = [NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 17)]
        attributedQuotoverview.addAttributes(attributesattributedoverview, range: NSRange(location: 0, length: 8))
        
        self.lbl_Overview.attributedText = attributedQuotoverview
        
    }


}

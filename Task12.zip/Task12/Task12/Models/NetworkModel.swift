//
//  NetworkModel.swift
//  Task12
//
//  Created byTushar Ingale on 28/04/22.
//

// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? newJSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

// MARK: - Welcome
struct Welcome: Codable {
    let swagger: String
//    let info: Info
//    let host, basePath: String
//    let schemes, consumes, produces: [String]
    let paths: Paths
//    let parameters: Parameters
//    let responses: Responses
//    let definitions: Definitions
}

// MARK: - Definitions
struct Definitions: Codable {
    let imagePath: ImagePath
    let movieListObject, movieListResultWithRatingObject: MovieListObject
    let movieListResultsObjectWithMediaType: MovieListResultsObjectWithMediaType
    let personListResultObjectWithMediaType: PersonListResultObjectWithMediaType
    let personListResultsObject: PersonListResultsObject
    let tvListResultObject, tvListResultWithRatingObject: TvListResultObject
    let tvListResultsObjectWithMediaType: TvListResultsObjectWithMediaType

    enum CodingKeys: String, CodingKey {
        case imagePath = "image-path"
        case movieListObject = "movie-list-object"
        case movieListResultWithRatingObject = "movie-list-result-with-rating-object"
        case movieListResultsObjectWithMediaType = "movie-list-results-object-with-media_type"
        case personListResultObjectWithMediaType = "person-list-result-object-with-media-type"
        case personListResultsObject = "person-list-results-object"
        case tvListResultObject = "tv-list-result-object"
        case tvListResultWithRatingObject = "tv-list-result-with-rating-object"
        case tvListResultsObjectWithMediaType = "tv-list-results-object-with-media_type"
    }
}

// MARK: - ImagePath
struct ImagePath: Codable {
    let title: String
    let type: [TypeElement]
}

enum TypeElement: String, Codable {
    case boolean = "boolean"
    case integer = "integer"
    case null = "null"
    case number = "number"
    case string = "string"
}

// MARK: - MovieListObject
struct MovieListObject: Codable {
    let title: String
    let type: AccountRatingType
    let properties: MovieListObjectProperties
}

// MARK: - MovieListObjectProperties
struct MovieListObjectProperties: Codable {
    let posterPath: BackdropPath
    let adult, overview, releaseDate: AdultValue
    let genreIDS: GenreIDS
    let id, originalTitle, originalLanguage, title: AdultValue
    let backdropPath: BackdropPath
    let popularity, voteCount, video, voteAverage: AdultValue
    let rating: AdultValue?
    let mediaType: MediaType?
    let accountRating: PropertiesAccountRating?

    enum CodingKeys: String, CodingKey {
        case posterPath = "poster_path"
        case adult, overview
        case releaseDate = "release_date"
        case genreIDS = "genre_ids"
        case id
        case originalTitle = "original_title"
        case originalLanguage = "original_language"
        case title
        case backdropPath = "backdrop_path"
        case popularity
        case voteCount = "vote_count"
        case video
        case voteAverage = "vote_average"
        case rating
        case mediaType = "media_type"
        case accountRating = "account_rating"
    }
}

// MARK: - PropertiesAccountRating
struct PropertiesAccountRating: Codable {
    let type: AccountRatingType
    let properties: AccountRatingProperties
}

// MARK: - AccountRatingProperties
struct AccountRatingProperties: Codable {
    let value, createdAt: AdultValue

    enum CodingKeys: String, CodingKey {
        case value
        case createdAt = "created_at"
    }
}

// MARK: - AdultValue
struct AdultValue: Codable {
    let type: TypeElement
}

enum AccountRatingType: String, Codable {
    case object = "object"
}

// MARK: - BackdropPath
struct BackdropPath: Codable {
    let ref: String

    enum CodingKeys: String, CodingKey {
        case ref = "$ref"
    }
}

// MARK: - GenreIDS
struct GenreIDS: Codable {
    let type: GenreIDSType
    let items: AdultValue
}

enum GenreIDSType: String, Codable {
    case array = "array"
}

// MARK: - MediaType
struct MediaType: Codable {
    let type: TypeElement
    let mediaTypeEnum: [String]

    enum CodingKeys: String, CodingKey {
        case type
        case mediaTypeEnum = "enum"
    }
}

// MARK: - MovieListResultsObjectWithMediaType
struct MovieListResultsObjectWithMediaType: Codable {
    let title: String
    let type: AccountRatingType
    let properties: MovieListObjectProperties
    let movieListResultsObjectWithMediaTypeRequired: [String]

    enum CodingKeys: String, CodingKey {
        case title, type, properties
        case movieListResultsObjectWithMediaTypeRequired = "required"
    }
}

// MARK: - PersonListResultObjectWithMediaType
struct PersonListResultObjectWithMediaType: Codable {
    let title: String
    let type: AccountRatingType
    let properties: PersonListResultObjectWithMediaTypeProperties
    let personListResultObjectWithMediaTypeRequired: [String]

    enum CodingKeys: String, CodingKey {
        case title, type, properties
        case personListResultObjectWithMediaTypeRequired = "required"
    }
}

// MARK: - PersonListResultObjectWithMediaTypeProperties
struct PersonListResultObjectWithMediaTypeProperties: Codable {
    let profilePath: BackdropPath
    let adult, id: AdultValue
    let mediaType: MediaType?
    let knownFor: KnownFor
    let name, popularity: AdultValue

    enum CodingKeys: String, CodingKey {
        case profilePath = "profile_path"
        case adult, id
        case mediaType = "media_type"
        case knownFor = "known_for"
        case name, popularity
    }
}

// MARK: - KnownFor
struct KnownFor: Codable {
    let type: GenreIDSType
    let items: KnownForItems
}

// MARK: - KnownForItems
struct KnownForItems: Codable {
    let oneOf: [BackdropPath]
}

// MARK: - PersonListResultsObject
struct PersonListResultsObject: Codable {
    let title: String
    let type: AccountRatingType
    let properties: PersonListResultObjectWithMediaTypeProperties
}

// MARK: - TvListResultObject
struct TvListResultObject: Codable {
    let title: String
    let type: AccountRatingType
    let properties: TvListResultObjectProperties
}

// MARK: - TvListResultObjectProperties
struct TvListResultObjectProperties: Codable {
    let posterPath: BackdropPath
    let popularity, id: AdultValue
    let backdropPath: BackdropPath
    let voteAverage, overview, firstAirDate: AdultValue
    let originCountry, genreIDS: GenreIDS
    let originalLanguage, voteCount, name, originalName: AdultValue
    let rating: AdultValue?
    let mediaType: MediaType?
    let accountRating: PropertiesAccountRating?

    enum CodingKeys: String, CodingKey {
        case posterPath = "poster_path"
        case popularity, id
        case backdropPath = "backdrop_path"
        case voteAverage = "vote_average"
        case overview
        case firstAirDate = "first_air_date"
        case originCountry = "origin_country"
        case genreIDS = "genre_ids"
        case originalLanguage = "original_language"
        case voteCount = "vote_count"
        case name
        case originalName = "original_name"
        case rating
        case mediaType = "media_type"
        case accountRating = "account_rating"
    }
}

// MARK: - TvListResultsObjectWithMediaType
struct TvListResultsObjectWithMediaType: Codable {
    let title: String
    let type: AccountRatingType
    let properties: TvListResultObjectProperties
    let tvListResultsObjectWithMediaTypeRequired: [String]

    enum CodingKeys: String, CodingKey {
        case title, type, properties
        case tvListResultsObjectWithMediaTypeRequired = "required"
    }
}

// MARK: - Info
struct Info: Codable {
    let version, title, infoDescription: String

    enum CodingKeys: String, CodingKey {
        case version, title
        case infoDescription = "description"
    }
}

// MARK: - Parameters
struct Parameters: Codable {
    let traitAccountMovieListSortOptionsSortBy: TraitAccountMovieListSortOptionsSortBy
    let traitLanguageParamLanguage: TraitLanguageParamLanguage
    let traitUserAuthorizationAuthorization: Trait
    let traitPageParamPage: TraitPageParamPage
    let traitAccountTvListSortOptionsSortBy: TraitAccountMovieListSortOptionsSortBy
    let traitAppAuthorizationAPIKey: TraitAppAuthorizationAPIKey
    let traitAppAuthorizationAuthorization, traitContentTypeContentType: Trait
    let traitPageWithMaxParamPage: TraitPageWithMaxParamPage

    enum CodingKeys: String, CodingKey {
        case traitAccountMovieListSortOptionsSortBy = "trait:accountMovieListSortOptions:sort_by"
        case traitLanguageParamLanguage = "trait:languageParam:language"
        case traitUserAuthorizationAuthorization = "trait:userAuthorization:Authorization"
        case traitPageParamPage = "trait:pageParam:page"
        case traitAccountTvListSortOptionsSortBy = "trait:accountTvListSortOptions:sort_by"
        case traitAppAuthorizationAPIKey = "trait:appAuthorization:api_key"
        case traitAppAuthorizationAuthorization = "trait:appAuthorization:Authorization"
        case traitContentTypeContentType = "trait:contentType:Content-Type"
        case traitPageWithMaxParamPage = "trait:pageWithMaxParam:page"
    }
}

// MARK: - TraitAccountMovieListSortOptionsSortBy
struct TraitAccountMovieListSortOptionsSortBy: Codable {
    let name: String?
    let traitAccountMovieListSortOptionsSortByIn: In?
    let traitAccountMovieListSortOptionsSortByDescription: String?
    let type: TypeElement?
    let traitAccountMovieListSortOptionsSortByEnum: [String]?
    let ref: String?

    enum CodingKeys: String, CodingKey {
        case name
        case traitAccountMovieListSortOptionsSortByIn = "in"
        case traitAccountMovieListSortOptionsSortByDescription = "description"
        case type
        case traitAccountMovieListSortOptionsSortByEnum = "enum"
        case ref = "$ref"
    }
}

enum In: String, Codable {
    case path = "path"
    case query = "query"
}

// MARK: - TraitAppAuthorizationAPIKey
struct TraitAppAuthorizationAPIKey: Codable {
    let name: Name
    let traitAppAuthorizationAPIKeyIn: In
    let type: TypeElement
    let traitAppAuthorizationAPIKeyDefault: String?
    let traitAppAuthorizationAPIKeyRequired: Bool?

    enum CodingKeys: String, CodingKey {
        case name
        case traitAppAuthorizationAPIKeyIn = "in"
        case type
        case traitAppAuthorizationAPIKeyDefault = "default"
        case traitAppAuthorizationAPIKeyRequired = "required"
    }
}

enum Name: String, Codable {
    case accountID = "account_id"
    case apiKey = "api_key"
    case listID = "list_id"
}

// MARK: - Trait
struct Trait: Codable {
    let name, traitIn, traitDescription: String
    let type: TypeElement
    let pattern: String?
    let traitDefault: String
    let traitRequired: Bool?

    enum CodingKeys: String, CodingKey {
        case name
        case traitIn = "in"
        case traitDescription = "description"
        case type, pattern
        case traitDefault = "default"
        case traitRequired = "required"
    }
}

// MARK: - TraitLanguageParamLanguage
struct TraitLanguageParamLanguage: Codable {
    let name: String
    let traitLanguageParamLanguageIn: In
    let type: TypeElement
    let minLength: Int
    let pattern: String

    enum CodingKeys: String, CodingKey {
        case name
        case traitLanguageParamLanguageIn = "in"
        case type, minLength, pattern
    }
}

// MARK: - TraitPageParamPage
struct TraitPageParamPage: Codable {
    let name: String
    let traitPageParamPageIn: In
    let type: TypeElement
    let minimum, traitPageParamPageDefault: Int

    enum CodingKeys: String, CodingKey {
        case name
        case traitPageParamPageIn = "in"
        case type, minimum
        case traitPageParamPageDefault = "default"
    }
}

// MARK: - TraitPageWithMaxParamPage
struct TraitPageWithMaxParamPage: Codable {
    let name: String
    let traitPageWithMaxParamPageIn: In
    let traitPageWithMaxParamPageRequired: Bool
    let type: TypeElement
    let minimum, maximum: Int

    enum CodingKeys: String, CodingKey {
        case name
        case traitPageWithMaxParamPageIn = "in"
        case traitPageWithMaxParamPageRequired = "required"
        case type, minimum, maximum
    }
}

// MARK: - Paths
struct Paths: Codable {
    let accountAccountIDTvWatchlist: AccountAccountIDTv
    let accountAccountIDMovieRated: AccountAccountIDMovieRated
    let authAccessToken: AuthAccessToken
    let accountAccountIDTvFavorites: AccountAccountIDTv
    let authRequestToken: AuthRequestToken
    let listListIDItems: ListListIDItems
    let listListIDItemStatus: ListListIDItemStatus
    let listListID: ListListID
    let accountAccountIDTvRated: AccountAccountIDTvRated
    let accountAccountIDMovieRecommendations: AccountAccountIDMovieRecommendations
    let accountAccountIDMovieWatchlist: AccountAccountIDMovie
    let accountAccountIDTvRecommendations: AccountAccountIDTvRecommendations
    let listListIDClear: ListListIDClear
    let accountAccountIDLists: AccountAccountIDLists
    let accountAccountIDMovieFavorites: AccountAccountIDMovie
    let list: List

    enum CodingKeys: String, CodingKey {
        case accountAccountIDTvWatchlist = "/account/{account_id}/tv/watchlist"
        case accountAccountIDMovieRated = "/account/{account_id}/movie/rated"
        case authAccessToken = "/auth/access_token"
        case accountAccountIDTvFavorites = "/account/{account_id}/tv/favorites"
        case authRequestToken = "/auth/request_token"
        case listListIDItems = "/list/{list_id}/items"
        case listListIDItemStatus = "/list/{list_id}/item_status"
        case listListID = "/list/{list_id}"
        case accountAccountIDTvRated = "/account/{account_id}/tv/rated"
        case accountAccountIDMovieRecommendations = "/account/{account_id}/movie/recommendations"
        case accountAccountIDMovieWatchlist = "/account/{account_id}/movie/watchlist"
        case accountAccountIDTvRecommendations = "/account/{account_id}/tv/recommendations"
        case listListIDClear = "/list/{list_id}/clear"
        case accountAccountIDLists = "/account/{account_id}/lists"
        case accountAccountIDMovieFavorites = "/account/{account_id}/movie/favorites"
        case list = "/list"
    }
}

// MARK: - AccountAccountIDLists
struct AccountAccountIDLists: Codable {
    let parameters: [TraitAppAuthorizationAPIKey]
    let accountAccountIDListsGet: AccountAccountIDListsGet

    enum CodingKeys: String, CodingKey {
        case parameters
        case accountAccountIDListsGet = "get"
    }
}

// MARK: - AccountAccountIDListsGet
struct AccountAccountIDListsGet: Codable {
    let operationID, summary, getDescription: String
    let parameters: [BackdropPath]
    let responses: [String: PurpleResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary
        case getDescription = "description"
        case parameters, responses
    }
}

// MARK: - PurpleResponse
struct PurpleResponse: Codable {
    let responseDescription: String?
    let schema: PurpleSchema?
    let examples: PurpleExamples?
    let ref: String?

    enum CodingKeys: String, CodingKey {
        case responseDescription = "description"
        case schema, examples
        case ref = "$ref"
    }
}

// MARK: - PurpleExamples
struct PurpleExamples: Codable {
    let applicationJSON: PurpleApplicationJSON

    enum CodingKeys: String, CodingKey {
        case applicationJSON = "application/json"
    }
}

// MARK: - PurpleApplicationJSON
struct PurpleApplicationJSON: Codable {
    let page, totalResults, totalPages: Int?
    let results: [PurpleResult]?
    let posterPath: String?
    let id: Int?
    let backdropPath: String?
    let applicationJSONPublic: Bool?
    let revenue: String?
    let objectIDS: [String: String?]?
    let iso639_1: ISO639_1?
    let applicationJSONDescription: String?
    let createdBy: ApplicationJSONCreatedBy?
    let iso3166_1: ISO3166_1?
    let averageRating: Double?
    let runtime: Int?
    let name: String?
    let comments: [String: String?]?
    let mediaType: String?
    let success: Bool?
    let statusMessage: String?
    let mediaID, statusCode: Int?
    let requestToken: String?
    let itemsDeleted: Int?

    enum CodingKeys: String, CodingKey {
        case page
        case totalResults = "total_results"
        case totalPages = "total_pages"
        case results
        case posterPath = "poster_path"
        case id
        case backdropPath = "backdrop_path"
        case applicationJSONPublic = "public"
        case revenue
        case objectIDS = "object_ids"
        case iso639_1 = "iso_639_1"
        case applicationJSONDescription = "description"
        case createdBy = "created_by"
        case iso3166_1 = "iso_3166_1"
        case averageRating = "average_rating"
        case runtime, name, comments
        case mediaType = "media_type"
        case success
        case statusMessage = "status_message"
        case mediaID = "media_id"
        case statusCode = "status_code"
        case requestToken = "request_token"
        case itemsDeleted = "items_deleted"
    }
}

// MARK: - ApplicationJSONCreatedBy
struct ApplicationJSONCreatedBy: Codable {
    let gravatarHash, name, username: String

    enum CodingKeys: String, CodingKey {
        case gravatarHash = "gravatar_hash"
        case name, username
    }
}

enum ISO3166_1: String, Codable {
    case ca = "CA"
    case gb = "GB"
    case ie = "IE"
    case us = "US"
}

enum ISO639_1: String, Codable {
    case en = "en"
    case pl = "pl"
}

// MARK: - PurpleResult
struct PurpleResult: Codable {
    let iso639_1: ISO639_1?
    let id, featured: Int?
    let resultDescription, revenue: String?
    let resultPublic: Int?
    let name, updatedAt, createdAt: String?
    let sortBy: Int?
    let backdropPath: String?
    let runtime: Int?
    let averageRating: Double?
    let iso3166_1: ISO3166_1?
    let adult: AdultUnion?
    let numberOfItems: Int?
    let posterPath, overview, releaseDate, originalTitle: String?
    let genreIDS: [Int]?
    let mediaType: String?
    let originalLanguage: ISO639_1?
    let title: String?
    let popularity: Double?
    let voteCount: Int?
    let video: Bool?
    let voteAverage: Double?
    let mediaID: Int?
    let success: Bool?

    enum CodingKeys: String, CodingKey {
        case iso639_1 = "iso_639_1"
        case id, featured
        case resultDescription = "description"
        case revenue
        case resultPublic = "public"
        case name
        case updatedAt = "updated_at"
        case createdAt = "created_at"
        case sortBy = "sort_by"
        case backdropPath = "backdrop_path"
        case runtime
        case averageRating = "average_rating"
        case iso3166_1 = "iso_3166_1"
        case adult
        case numberOfItems = "number_of_items"
        case posterPath = "poster_path"
        case overview
        case releaseDate = "release_date"
        case originalTitle = "original_title"
        case genreIDS = "genre_ids"
        case mediaType = "media_type"
        case originalLanguage = "original_language"
        case title, popularity
        case voteCount = "vote_count"
        case video
        case voteAverage = "vote_average"
        case mediaID = "media_id"
        case success
    }
}

enum AdultUnion: Codable {
    case bool(Bool)
    case integer(Int)

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let x = try? container.decode(Bool.self) {
            self = .bool(x)
            return
        }
        if let x = try? container.decode(Int.self) {
            self = .integer(x)
            return
        }
        throw DecodingError.typeMismatch(AdultUnion.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for AdultUnion"))
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch self {
        case .bool(let x):
            try container.encode(x)
        case .integer(let x):
            try container.encode(x)
        }
    }
}

// MARK: - PurpleSchema
struct PurpleSchema: Codable {
    let type: AccountRatingType
    let properties: PurpleProperties
}

// MARK: - PurpleProperties
struct PurpleProperties: Codable {
    let page, totalResults, totalPages: AdultValue?
    let results: PurpleResults?
    let posterPath: BackdropPath?
    let id: AdultValue?
    let backdropPath: BackdropPath?
    let propertiesPublic, revenue, iso639_1, propertiesDescription: AdultValue?
    let createdBy: PropertiesCreatedBy?
    let iso3166_1, averageRating, runtime, name: AdultValue?
    let comments: Comments?
    let mediaType, success, statusMessage, mediaID: AdultValue?
    let statusCode, requestToken, itemsDeleted, errorMessage: AdultValue?

    enum CodingKeys: String, CodingKey {
        case page
        case totalResults = "total_results"
        case totalPages = "total_pages"
        case results
        case posterPath = "poster_path"
        case id
        case backdropPath = "backdrop_path"
        case propertiesPublic = "public"
        case revenue
        case iso639_1 = "iso_639_1"
        case propertiesDescription = "description"
        case createdBy = "created_by"
        case iso3166_1 = "iso_3166_1"
        case averageRating = "average_rating"
        case runtime, name, comments
        case mediaType = "media_type"
        case success
        case statusMessage = "status_message"
        case mediaID = "media_id"
        case statusCode = "status_code"
        case requestToken = "request_token"
        case itemsDeleted = "items_deleted"
        case errorMessage = "error_message"
    }
}

// MARK: - Comments
struct Comments: Codable {
    let type: AccountRatingType
    let properties: [String: AdultValue]
}

// MARK: - PropertiesCreatedBy
struct PropertiesCreatedBy: Codable {
    let type: AccountRatingType
    let properties: CreatedByProperties
}

// MARK: - CreatedByProperties
struct CreatedByProperties: Codable {
    let gravatarHash, name, username: AdultValue

    enum CodingKeys: String, CodingKey {
        case gravatarHash = "gravatar_hash"
        case name, username
    }
}

// MARK: - PurpleResults
struct PurpleResults: Codable {
    let type: GenreIDSType
    let items: PurpleItems
}

// MARK: - PurpleItems
struct PurpleItems: Codable {
    let type: AccountRatingType?
    let properties: [String: AdultValue]?
    let oneOf: [BackdropPath]?
}

// MARK: - AccountAccountIDMovie
struct AccountAccountIDMovie: Codable {
    let parameters: [TraitAppAuthorizationAPIKey]
    let accountAccountIDMovieGet: AccountAccountIDMovieFavoritesGet

    enum CodingKeys: String, CodingKey {
        case parameters
        case accountAccountIDMovieGet = "get"
    }
}

// MARK: - AccountAccountIDMovieFavoritesGet
struct AccountAccountIDMovieFavoritesGet: Codable {
    let operationID, summary, getDescription: String
    let parameters: [BackdropPath]
    let responses: [String: PutResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary
        case getDescription = "description"
        case parameters, responses
    }
}

// MARK: - PutResponse
struct PutResponse: Codable {
    let responseDescription: String?
    let schema: FluffySchema?
    let examples: FluffyExamples?
    let ref: String?

    enum CodingKeys: String, CodingKey {
        case responseDescription = "description"
        case schema, examples
        case ref = "$ref"
    }
}

// MARK: - FluffyExamples
struct FluffyExamples: Codable {
    let applicationJSON: FluffyApplicationJSON

    enum CodingKeys: String, CodingKey {
        case applicationJSON = "application/json"
    }
}

// MARK: - FluffyApplicationJSON
struct FluffyApplicationJSON: Codable {
    let page: Int?
    let results: [FluffyResult]?
    let totalResults, totalPages, itemsDeleted: Int?
    let statusMessage: String?
    let id, statusCode: Int?
    let success: Bool?
    let requestToken: String?

    enum CodingKeys: String, CodingKey {
        case page, results
        case totalResults = "total_results"
        case totalPages = "total_pages"
        case itemsDeleted = "items_deleted"
        case statusMessage = "status_message"
        case id
        case statusCode = "status_code"
        case success
        case requestToken = "request_token"
    }
}

// MARK: - FluffyResult
struct FluffyResult: Codable {
    let posterPath: String?
    let adult: Bool?
    let overview, releaseDate: String?
    let genreIDS: [Int]?
    let id: Int?
    let originalTitle: String?
    let originalLanguage: ISO639_1?
    let title: String?
    let backdropPath: JSONNull?
    let popularity: Double?
    let voteCount: Int?
    let video: Bool?
    let voteAverage: Double?
    let mediaType: String?
    let mediaID: Int?
    let success: Bool?

    enum CodingKeys: String, CodingKey {
        case posterPath = "poster_path"
        case adult, overview
        case releaseDate = "release_date"
        case genreIDS = "genre_ids"
        case id
        case originalTitle = "original_title"
        case originalLanguage = "original_language"
        case title
        case backdropPath = "backdrop_path"
        case popularity
        case voteCount = "vote_count"
        case video
        case voteAverage = "vote_average"
        case mediaType = "media_type"
        case mediaID = "media_id"
        case success
    }
}

// MARK: - FluffySchema
struct FluffySchema: Codable {
    let type: AccountRatingType
    let properties: FluffyProperties
}

// MARK: - FluffyProperties
struct FluffyProperties: Codable {
    let page: AdultValue?
    let results: FluffyResults?
    let totalResults, totalPages, itemsDeleted, statusMessage: AdultValue?
    let id, statusCode, success, requestToken: AdultValue?
    let errorMessage: AdultValue?

    enum CodingKeys: String, CodingKey {
        case page, results
        case totalResults = "total_results"
        case totalPages = "total_pages"
        case itemsDeleted = "items_deleted"
        case statusMessage = "status_message"
        case id
        case statusCode = "status_code"
        case success
        case requestToken = "request_token"
        case errorMessage = "error_message"
    }
}

// MARK: - FluffyResults
struct FluffyResults: Codable {
    let type: GenreIDSType
    let items: FluffyItems
}

// MARK: - FluffyItems
struct FluffyItems: Codable {
    let ref: String?
    let type: AccountRatingType?
    let properties: TentacledProperties?

    enum CodingKeys: String, CodingKey {
        case ref = "$ref"
        case type, properties
    }
}

// MARK: - TentacledProperties
struct TentacledProperties: Codable {
    let mediaType, mediaID, success: AdultValue

    enum CodingKeys: String, CodingKey {
        case mediaType = "media_type"
        case mediaID = "media_id"
        case success
    }
}

// MARK: - AccountAccountIDMovieRated
struct AccountAccountIDMovieRated: Codable {
    let parameters: [TraitAppAuthorizationAPIKey]
    let accountAccountIDMovieRatedGet: AccountAccountIDMovieRatedGet

    enum CodingKeys: String, CodingKey {
        case parameters
        case accountAccountIDMovieRatedGet = "get"
    }
}

// MARK: - AccountAccountIDMovieRatedGet
struct AccountAccountIDMovieRatedGet: Codable {
    let operationID, summary, getDescription: String
    let parameters: [BackdropPath]
    let responses: [String: FluffyResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary
        case getDescription = "description"
        case parameters, responses
    }
}

// MARK: - FluffyResponse
struct FluffyResponse: Codable {
    let responseDescription: String?
    let schema: TentacledSchema?
    let examples: TentacledExamples?
    let ref: String?

    enum CodingKeys: String, CodingKey {
        case responseDescription = "description"
        case schema, examples
        case ref = "$ref"
    }
}

// MARK: - TentacledExamples
struct TentacledExamples: Codable {
    let applicationJSON: TentacledApplicationJSON

    enum CodingKeys: String, CodingKey {
        case applicationJSON = "application/json"
    }
}

// MARK: - TentacledApplicationJSON
struct TentacledApplicationJSON: Codable {
    let page, totalResults, totalPages: Int
    let results: [TentacledResult]

    enum CodingKeys: String, CodingKey {
        case page
        case totalResults = "total_results"
        case totalPages = "total_pages"
        case results
    }
}

// MARK: - TentacledResult
struct TentacledResult: Codable {
    let posterPath: String?
    let adult: Bool
    let overview, releaseDate: String
    let genreIDS: [Int]
    let id: Int
    let originalTitle: String
    let originalLanguage: ISO639_1
    let title: String
    let backdropPath: String?
    let popularity: Double
    let voteCount: Int
    let video: Bool
    let voteAverage: Double
    let accountRating: ResultAccountRating?
    let mediaType: String?

    enum CodingKeys: String, CodingKey {
        case posterPath = "poster_path"
        case adult, overview
        case releaseDate = "release_date"
        case genreIDS = "genre_ids"
        case id
        case originalTitle = "original_title"
        case originalLanguage = "original_language"
        case title
        case backdropPath = "backdrop_path"
        case popularity
        case voteCount = "vote_count"
        case video
        case voteAverage = "vote_average"
        case accountRating = "account_rating"
        case mediaType = "media_type"
    }
}

// MARK: - ResultAccountRating
struct ResultAccountRating: Codable {
    let value: Int
    let createdAt: String

    enum CodingKeys: String, CodingKey {
        case value
        case createdAt = "created_at"
    }
}

// MARK: - TentacledSchema
struct TentacledSchema: Codable {
    let type: AccountRatingType
    let properties: StickyProperties
}

// MARK: - StickyProperties
struct StickyProperties: Codable {
    let page, totalResults, totalPages: AdultValue
    let results: TentacledResults

    enum CodingKeys: String, CodingKey {
        case page
        case totalResults = "total_results"
        case totalPages = "total_pages"
        case results
    }
}

// MARK: - TentacledResults
struct TentacledResults: Codable {
    let type: GenreIDSType
    let items: TentacledItems
}

// MARK: - TentacledItems
struct TentacledItems: Codable {
    let type: AccountRatingType
    let properties: MovieListObjectProperties
}

// MARK: - AccountAccountIDMovieRecommendations
struct AccountAccountIDMovieRecommendations: Codable {
    let parameters: [TraitAppAuthorizationAPIKey]
    let accountAccountIDMovieRecommendationsGet: AccountAccountIDMovieRecommendationsGet

    enum CodingKeys: String, CodingKey {
        case parameters
        case accountAccountIDMovieRecommendationsGet = "get"
    }
}

// MARK: - AccountAccountIDMovieRecommendationsGet
struct AccountAccountIDMovieRecommendationsGet: Codable {
    let operationID, summary, getDescription: String
    let parameters: [TraitAccountMovieListSortOptionsSortBy]
    let responses: [String: PutResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary
        case getDescription = "description"
        case parameters, responses
    }
}

// MARK: - AccountAccountIDTv
struct AccountAccountIDTv: Codable {
    let parameters: [TraitAppAuthorizationAPIKey]
    let accountAccountIDTvGet: AccountAccountIDTvFavoritesGet

    enum CodingKeys: String, CodingKey {
        case parameters
        case accountAccountIDTvGet = "get"
    }
}

// MARK: - AccountAccountIDTvFavoritesGet
struct AccountAccountIDTvFavoritesGet: Codable {
    let operationID, summary, getDescription: String
    let parameters: [BackdropPath]
    let responses: [String: TentacledResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary
        case getDescription = "description"
        case parameters, responses
    }
}

// MARK: - TentacledResponse
struct TentacledResponse: Codable {
    let responseDescription: String?
    let schema: StickySchema?
    let examples: StickyExamples?
    let ref: String?

    enum CodingKeys: String, CodingKey {
        case responseDescription = "description"
        case schema, examples
        case ref = "$ref"
    }
}

// MARK: - StickyExamples
struct StickyExamples: Codable {
    let applicationJSON: StickyApplicationJSON

    enum CodingKeys: String, CodingKey {
        case applicationJSON = "application/json"
    }
}

// MARK: - StickyApplicationJSON
struct StickyApplicationJSON: Codable {
    let page: Int
    let results: [StickyResult]
    let totalResults, totalPages: Int

    enum CodingKeys: String, CodingKey {
        case page, results
        case totalResults = "total_results"
        case totalPages = "total_pages"
    }
}

// MARK: - StickyResult
struct StickyResult: Codable {
    let posterPath: String?
    let popularity: Double
    let id: Int
    let backdropPath: String?
    let voteAverage: Double
    let overview, firstAirDate: String
    let originCountry: [ISO3166_1]
    let genreIDS: [Int]
    let originalLanguage: ISO639_1
    let voteCount: Int
    let name, originalName: String
    let accountRating: ResultAccountRating?

    enum CodingKeys: String, CodingKey {
        case posterPath = "poster_path"
        case popularity, id
        case backdropPath = "backdrop_path"
        case voteAverage = "vote_average"
        case overview
        case firstAirDate = "first_air_date"
        case originCountry = "origin_country"
        case genreIDS = "genre_ids"
        case originalLanguage = "original_language"
        case voteCount = "vote_count"
        case name
        case originalName = "original_name"
        case accountRating = "account_rating"
    }
}

// MARK: - StickySchema
struct StickySchema: Codable {
    let type: AccountRatingType
    let properties: IndigoProperties
}

// MARK: - IndigoProperties
struct IndigoProperties: Codable {
    let page: AdultValue
    let results: StickyResults
    let totalResults, totalPages: AdultValue

    enum CodingKeys: String, CodingKey {
        case page, results
        case totalResults = "total_results"
        case totalPages = "total_pages"
    }
}

// MARK: - StickyResults
struct StickyResults: Codable {
    let type: GenreIDSType
    let items: BackdropPath
}

// MARK: - AccountAccountIDTvRated
struct AccountAccountIDTvRated: Codable {
    let parameters: [TraitAppAuthorizationAPIKey]
    let accountAccountIDTvRatedGet: AccountAccountIDTvRatedGet

    enum CodingKeys: String, CodingKey {
        case parameters
        case accountAccountIDTvRatedGet = "get"
    }
}

// MARK: - AccountAccountIDTvRatedGet
struct AccountAccountIDTvRatedGet: Codable {
    let operationID, summary, getDescription: String
    let parameters: [BackdropPath]
    let responses: [String: StickyResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary
        case getDescription = "description"
        case parameters, responses
    }
}

// MARK: - StickyResponse
struct StickyResponse: Codable {
    let responseDescription: String?
    let schema: IndigoSchema?
    let examples: StickyExamples?
    let ref: String?

    enum CodingKeys: String, CodingKey {
        case responseDescription = "description"
        case schema, examples
        case ref = "$ref"
    }
}

// MARK: - IndigoSchema
struct IndigoSchema: Codable {
    let type: AccountRatingType
    let properties: IndecentProperties
}

// MARK: - IndecentProperties
struct IndecentProperties: Codable {
    let page, totalResults, totalPages: AdultValue
    let results: IndigoResults

    enum CodingKeys: String, CodingKey {
        case page
        case totalResults = "total_results"
        case totalPages = "total_pages"
        case results
    }
}

// MARK: - IndigoResults
struct IndigoResults: Codable {
    let type: GenreIDSType
    let items: StickyItems
}

// MARK: - StickyItems
struct StickyItems: Codable {
    let type: AccountRatingType
    let properties: TvListResultObjectProperties
}

// MARK: - AccountAccountIDTvRecommendations
struct AccountAccountIDTvRecommendations: Codable {
    let parameters: [TraitAppAuthorizationAPIKey]
    let accountAccountIDTvRecommendationsGet: AccountAccountIDTvRecommendationsGet

    enum CodingKeys: String, CodingKey {
        case parameters
        case accountAccountIDTvRecommendationsGet = "get"
    }
}

// MARK: - AccountAccountIDTvRecommendationsGet
struct AccountAccountIDTvRecommendationsGet: Codable {
    let operationID, summary, getDescription: String
    let parameters: [TraitAccountMovieListSortOptionsSortBy]
    let responses: [String: TentacledResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary
        case getDescription = "description"
        case parameters, responses
    }
}

// MARK: - AuthAccessToken
struct AuthAccessToken: Codable {
    let delete: AuthAccessTokenDelete
    let post: AuthAccessTokenPost
}

// MARK: - AuthAccessTokenDelete
struct AuthAccessTokenDelete: Codable {
    let operationID, summary, deleteDescription: String
    let parameters: [PurpleParameter]
    let responses: [String: IndigoResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary
        case deleteDescription = "description"
        case parameters, responses
    }
}

// MARK: - PurpleParameter
struct PurpleParameter: Codable {
    let name, parameterIn: String?
    let schema: IndecentSchema?
    let ref: String?

    enum CodingKeys: String, CodingKey {
        case name
        case parameterIn = "in"
        case schema
        case ref = "$ref"
    }
}

// MARK: - IndecentSchema
struct IndecentSchema: Codable {
    let type: AccountRatingType
    let properties: HilariousProperties
    let schemaRequired: [String]
    let example: PurpleExample

    enum CodingKeys: String, CodingKey {
        case type, properties
        case schemaRequired = "required"
        case example
    }
}

// MARK: - PurpleExample
struct PurpleExample: Codable {
    let accessToken: String

    enum CodingKeys: String, CodingKey {
        case accessToken = "access_token"
    }
}

// MARK: - HilariousProperties
struct HilariousProperties: Codable {
    let accessToken: AdultValue

    enum CodingKeys: String, CodingKey {
        case accessToken = "access_token"
    }
}

// MARK: - IndigoResponse
struct IndigoResponse: Codable {
    let responseDescription: String?
    let schema: HilariousSchema?
    let examples: IndigoExamples?
    let ref: String?

    enum CodingKeys: String, CodingKey {
        case responseDescription = "description"
        case schema, examples
        case ref = "$ref"
    }
}

// MARK: - IndigoExamples
struct IndigoExamples: Codable {
    let applicationJSON: IndigoApplicationJSON

    enum CodingKeys: String, CodingKey {
        case applicationJSON = "application/json"
    }
}

// MARK: - IndigoApplicationJSON
struct IndigoApplicationJSON: Codable {
    let statusMessage: String
    let success: Bool
    let statusCode: Int
    let requestToken: String?
    let id, itemsDeleted: Int?
    let results: [IndigoResult]?

    enum CodingKeys: String, CodingKey {
        case statusMessage = "status_message"
        case success
        case statusCode = "status_code"
        case requestToken = "request_token"
        case id
        case itemsDeleted = "items_deleted"
        case results
    }
}

// MARK: - IndigoResult
struct IndigoResult: Codable {
    let mediaType: String
    let mediaID: Int
    let success: Bool

    enum CodingKeys: String, CodingKey {
        case mediaType = "media_type"
        case mediaID = "media_id"
        case success
    }
}

// MARK: - HilariousSchema
struct HilariousSchema: Codable {
    let type: AccountRatingType
    let properties: AmbitiousProperties
}

// MARK: - AmbitiousProperties
struct AmbitiousProperties: Codable {
    let statusMessage, success, statusCode: AdultValue
    let requestToken, id, itemsDeleted: AdultValue?
    let results: IndecentResults?
    let errorMessage: AdultValue?

    enum CodingKeys: String, CodingKey {
        case statusMessage = "status_message"
        case success
        case statusCode = "status_code"
        case requestToken = "request_token"
        case id
        case itemsDeleted = "items_deleted"
        case results
        case errorMessage = "error_message"
    }
}

// MARK: - IndecentResults
struct IndecentResults: Codable {
    let type: GenreIDSType
    let items: IndigoItems
}

// MARK: - IndigoItems
struct IndigoItems: Codable {
    let type: AccountRatingType
    let properties: TentacledProperties
}

// MARK: - AuthAccessTokenPost
struct AuthAccessTokenPost: Codable {
    let operationID, summary, postDescription: String
    let parameters: [FluffyParameter]
    let responses: [String: IndecentResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary
        case postDescription = "description"
        case parameters, responses
    }
}

// MARK: - FluffyParameter
struct FluffyParameter: Codable {
    let name, parameterIn: String?
    let schema: AmbitiousSchema?
    let ref: String?

    enum CodingKeys: String, CodingKey {
        case name
        case parameterIn = "in"
        case schema
        case ref = "$ref"
    }
}

// MARK: - AmbitiousSchema
struct AmbitiousSchema: Codable {
    let type: AccountRatingType
    let properties: CunningProperties
    let schemaRequired: [String]
    let example: FluffyExample

    enum CodingKeys: String, CodingKey {
        case type, properties
        case schemaRequired = "required"
        case example
    }
}

// MARK: - FluffyExample
struct FluffyExample: Codable {
    let requestToken: String

    enum CodingKeys: String, CodingKey {
        case requestToken = "request_token"
    }
}

// MARK: - CunningProperties
struct CunningProperties: Codable {
    let requestToken: AdultValue

    enum CodingKeys: String, CodingKey {
        case requestToken = "request_token"
    }
}

// MARK: - IndecentResponse
struct IndecentResponse: Codable {
    let responseDescription: String?
    let schema: CunningSchema?
    let examples: IndecentExamples?
    let ref: String?

    enum CodingKeys: String, CodingKey {
        case responseDescription = "description"
        case schema, examples
        case ref = "$ref"
    }
}

// MARK: - IndecentExamples
struct IndecentExamples: Codable {
    let applicationJSON: IndecentApplicationJSON

    enum CodingKeys: String, CodingKey {
        case applicationJSON = "application/json"
    }
}

// MARK: - IndecentApplicationJSON
struct IndecentApplicationJSON: Codable {
    let accountID, accessToken: String
    let success: Bool
    let statusMessage: String
    let statusCode: Int

    enum CodingKeys: String, CodingKey {
        case accountID = "account_id"
        case accessToken = "access_token"
        case success
        case statusMessage = "status_message"
        case statusCode = "status_code"
    }
}

// MARK: - CunningSchema
struct CunningSchema: Codable {
    let type: AccountRatingType
    let properties: MagentaProperties
}

// MARK: - MagentaProperties
struct MagentaProperties: Codable {
    let statusMessage, accessToken, success, statusCode: AdultValue
    let accountID: AdultValue

    enum CodingKeys: String, CodingKey {
        case statusMessage = "status_message"
        case accessToken = "access_token"
        case success
        case statusCode = "status_code"
        case accountID = "account_id"
    }
}

// MARK: - AuthRequestToken
struct AuthRequestToken: Codable {
    let post: AuthRequestTokenPost
}

// MARK: - AuthRequestTokenPost
struct AuthRequestTokenPost: Codable {
    let operationID, summary, postDescription: String
    let parameters: [TentacledParameter]
    let responses: [String: IndigoResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary
        case postDescription = "description"
        case parameters, responses
    }
}

// MARK: - TentacledParameter
struct TentacledParameter: Codable {
    let name, parameterIn: String?
    let schema: MagentaSchema?
    let ref: String?

    enum CodingKeys: String, CodingKey {
        case name
        case parameterIn = "in"
        case schema
        case ref = "$ref"
    }
}

// MARK: - MagentaSchema
struct MagentaSchema: Codable {
    let type: AccountRatingType
    let properties: FriskyProperties
    let example: TentacledExample
}

// MARK: - TentacledExample
struct TentacledExample: Codable {
    let redirectTo: String

    enum CodingKeys: String, CodingKey {
        case redirectTo = "redirect_to"
    }
}

// MARK: - FriskyProperties
struct FriskyProperties: Codable {
    let redirectTo: AdultValue

    enum CodingKeys: String, CodingKey {
        case redirectTo = "redirect_to"
    }
}

// MARK: - List
struct List: Codable {
    let post: ListPost
}

// MARK: - ListPost
struct ListPost: Codable {
    let operationID, summary: String
    let tags: [String]
    let postDescription: String
    let parameters: [StickyParameter]
    let responses: [String: PurpleResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary, tags
        case postDescription = "description"
        case parameters, responses
    }
}

// MARK: - StickyParameter
struct StickyParameter: Codable {
    let name, parameterIn: String?
    let schema: FriskySchema?
    let ref: String?

    enum CodingKeys: String, CodingKey {
        case name
        case parameterIn = "in"
        case schema
        case ref = "$ref"
    }
}

// MARK: - FriskySchema
struct FriskySchema: Codable {
    let type: AccountRatingType
    let properties: MischievousProperties
    let schemaRequired: [String]
    let example: StickyExample

    enum CodingKeys: String, CodingKey {
        case type, properties
        case schemaRequired = "required"
        case example
    }
}

// MARK: - StickyExample
struct StickyExample: Codable {
    let name: String
    let iso639_1: ISO639_1

    enum CodingKeys: String, CodingKey {
        case name
        case iso639_1 = "iso_639_1"
    }
}

// MARK: - MischievousProperties
struct MischievousProperties: Codable {
    let name: Description
    let iso639_1: ISO
    let propertiesDescription: Description
    let propertiesPublic: Public
    let iso3166_1: ISO

    enum CodingKeys: String, CodingKey {
        case name
        case iso639_1 = "iso_639_1"
        case propertiesDescription = "description"
        case propertiesPublic = "public"
        case iso3166_1 = "iso_3166_1"
    }
}

// MARK: - ISO
struct ISO: Codable {
    let type: TypeElement
    let isoDefault, isoDescription: String
    let minLength, maxLength: Int

    enum CodingKeys: String, CodingKey {
        case type
        case isoDefault = "default"
        case isoDescription = "description"
        case minLength, maxLength
    }
}

// MARK: - Description
struct Description: Codable {
    let type: TypeElement
    let descriptionDescription: String

    enum CodingKeys: String, CodingKey {
        case type
        case descriptionDescription = "description"
    }
}

// MARK: - Public
struct Public: Codable {
    let type: TypeElement
    let publicDefault: Bool
    let publicDescription: String

    enum CodingKeys: String, CodingKey {
        case type
        case publicDefault = "default"
        case publicDescription = "description"
    }
}

// MARK: - ListListID
struct ListListID: Codable {
    let parameters: [TraitAppAuthorizationAPIKey]
    let listListIDGet: ListListIDGet
    let delete: ListListIDDelete
    let put: ListListIDPut

    enum CodingKeys: String, CodingKey {
        case parameters
        case listListIDGet = "get"
        case delete, put
    }
}

// MARK: - ListListIDDelete
struct ListListIDDelete: Codable {
    let operationID, summary: String
    let tags: [String]
    let deleteDescription: String
    let parameters: [BackdropPath]
    let responses: [String: IndigoResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary, tags
        case deleteDescription = "description"
        case parameters, responses
    }
}

// MARK: - ListListIDGet
struct ListListIDGet: Codable {
    let operationID, summary: String
    let tags: [String]
    let getDescription: String
    let parameters: [TraitAccountMovieListSortOptionsSortBy]
    let responses: [String: PurpleResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary, tags
        case getDescription = "description"
        case parameters, responses
    }
}

// MARK: - ListListIDPut
struct ListListIDPut: Codable {
    let operationID, summary: String
    let tags: [String]
    let putDescription: String
    let parameters: [IndigoParameter]
    let responses: [String: PutResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary, tags
        case putDescription = "description"
        case parameters, responses
    }
}

// MARK: - IndigoParameter
struct IndigoParameter: Codable {
    let name, parameterIn: String?
    let schema: MischievousSchema?
    let ref: String?

    enum CodingKeys: String, CodingKey {
        case name
        case parameterIn = "in"
        case schema
        case ref = "$ref"
    }
}

// MARK: - MischievousSchema
struct MischievousSchema: Codable {
    let type: AccountRatingType
    let properties: BraggadociousProperties
    let example: IndigoExample
}

// MARK: - IndigoExample
struct IndigoExample: Codable {
    let exampleDescription: String

    enum CodingKeys: String, CodingKey {
        case exampleDescription = "description"
    }
}

// MARK: - BraggadociousProperties
struct BraggadociousProperties: Codable {
    let propertiesDescription, name: Description
    let propertiesPublic: Public
    let sortBy: SortBy

    enum CodingKeys: String, CodingKey {
        case propertiesDescription = "description"
        case name
        case propertiesPublic = "public"
        case sortBy = "sort_by"
    }
}

// MARK: - SortBy
struct SortBy: Codable {
    let type: TypeElement
    let sortByDescription: String
    let sortByEnum: [String]

    enum CodingKeys: String, CodingKey {
        case type
        case sortByDescription = "description"
        case sortByEnum = "enum"
    }
}

// MARK: - ListListIDClear
struct ListListIDClear: Codable {
    let parameters: [TraitAppAuthorizationAPIKey]
    let listListIDClearGet: ListListIDClearGet

    enum CodingKeys: String, CodingKey {
        case parameters
        case listListIDClearGet = "get"
    }
}

// MARK: - ListListIDClearGet
struct ListListIDClearGet: Codable {
    let operationID, summary: String
    let tags: [String]
    let getDescription: String
    let parameters: [BackdropPath]
    let responses: [String: PutResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary, tags
        case getDescription = "description"
        case parameters, responses
    }
}

// MARK: - ListListIDItemStatus
struct ListListIDItemStatus: Codable {
    let parameters: [TraitAppAuthorizationAPIKey]
    let listListIDItemStatusGet: ListListIDItemStatusGet

    enum CodingKeys: String, CodingKey {
        case parameters
        case listListIDItemStatusGet = "get"
    }
}

// MARK: - ListListIDItemStatusGet
struct ListListIDItemStatusGet: Codable {
    let operationID, summary: String
    let tags: [String]
    let getDescription: String
    let parameters: [GetParameter]
    let responses: [String: PurpleResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary, tags
        case getDescription = "description"
        case parameters, responses
    }
}

// MARK: - GetParameter
struct GetParameter: Codable {
    let name: String?
    let parameterIn: In?
    let parameterRequired: Bool?
    let type: TypeElement?
    let parameterDefault: String?
    let parameterEnum: [String]?
    let ref: String?

    enum CodingKeys: String, CodingKey {
        case name
        case parameterIn = "in"
        case parameterRequired = "required"
        case type
        case parameterDefault = "default"
        case parameterEnum = "enum"
        case ref = "$ref"
    }
}

// MARK: - ListListIDItems
struct ListListIDItems: Codable {
    let parameters: [TraitAppAuthorizationAPIKey]
    let put: ListListIDItemsPut
    let delete: ListListIDItemsDelete
    let post: ListListIDItemsPost
}

// MARK: - ListListIDItemsDelete
struct ListListIDItemsDelete: Codable {
    let operationID, summary: String
    let tags: [String]
    let deleteDescription: String
    let parameters: [IndecentParameter]
    let responses: [String: PutResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary, tags
        case deleteDescription = "description"
        case parameters, responses
    }
}

// MARK: - IndecentParameter
struct IndecentParameter: Codable {
    let name, parameterIn: String?
    let schema: BraggadociousSchema?
    let ref: String?

    enum CodingKeys: String, CodingKey {
        case name
        case parameterIn = "in"
        case schema
        case ref = "$ref"
    }
}

// MARK: - BraggadociousSchema
struct BraggadociousSchema: Codable {
    let type: AccountRatingType
    let properties: Properties1
    let schemaRequired: [String]
    let example: IndecentExample

    enum CodingKeys: String, CodingKey {
        case type, properties
        case schemaRequired = "required"
        case example
    }
}

// MARK: - IndecentExample
struct IndecentExample: Codable {
    let items: [PurpleItem]
}

// MARK: - PurpleItem
struct PurpleItem: Codable {
    let mediaType: String
    let mediaID: Int

    enum CodingKeys: String, CodingKey {
        case mediaType = "media_type"
        case mediaID = "media_id"
    }
}

// MARK: - Properties1
struct Properties1: Codable {
    let items: IndecentItems
}

// MARK: - IndecentItems
struct IndecentItems: Codable {
    let type: GenreIDSType
    let items: HilariousItems
}

// MARK: - HilariousItems
struct HilariousItems: Codable {
    let type: AccountRatingType
    let properties: Properties2
    let itemsRequired: [String]

    enum CodingKeys: String, CodingKey {
        case type, properties
        case itemsRequired = "required"
    }
}

// MARK: - Properties2
struct Properties2: Codable {
    let mediaType: SortBy
    let mediaID: Description

    enum CodingKeys: String, CodingKey {
        case mediaType = "media_type"
        case mediaID = "media_id"
    }
}

// MARK: - ListListIDItemsPost
struct ListListIDItemsPost: Codable {
    let operationID, summary: String
    let tags: [String]
    let postDescription: String
    let parameters: [HilariousParameter]
    let responses: [String: PurpleResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary, tags
        case postDescription = "description"
        case parameters, responses
    }
}

// MARK: - HilariousParameter
struct HilariousParameter: Codable {
    let name, parameterIn: String?
    let schema: Schema1?
    let ref: String?

    enum CodingKeys: String, CodingKey {
        case name
        case parameterIn = "in"
        case schema
        case ref = "$ref"
    }
}

// MARK: - Schema1
struct Schema1: Codable {
    let type: AccountRatingType
    let properties: Properties3
    let schemaRequired: [String]
    let example: IndecentExample

    enum CodingKeys: String, CodingKey {
        case type, properties
        case schemaRequired = "required"
        case example
    }
}

// MARK: - Properties3
struct Properties3: Codable {
    let items: AmbitiousItems
}

// MARK: - AmbitiousItems
struct AmbitiousItems: Codable {
    let type: GenreIDSType
    let items: CunningItems
}

// MARK: - CunningItems
struct CunningItems: Codable {
    let type: AccountRatingType
    let properties: Properties4
    let itemsRequired: [String]

    enum CodingKeys: String, CodingKey {
        case type, properties
        case itemsRequired = "required"
    }
}

// MARK: - Properties4
struct Properties4: Codable {
    let mediaType: SortBy
    let mediaID: MediaID

    enum CodingKeys: String, CodingKey {
        case mediaType = "media_type"
        case mediaID = "media_id"
    }
}

// MARK: - MediaID
struct MediaID: Codable {
    let type: TypeElement
    let mediaIDDescription: String
    let minimum: Int

    enum CodingKeys: String, CodingKey {
        case type
        case mediaIDDescription = "description"
        case minimum
    }
}

// MARK: - ListListIDItemsPut
struct ListListIDItemsPut: Codable {
    let operationID, summary: String
    let tags: [String]
    let putDescription: String
    let parameters: [AmbitiousParameter]
    let responses: [String: PutResponse]

    enum CodingKeys: String, CodingKey {
        case operationID = "operationId"
        case summary, tags
        case putDescription = "description"
        case parameters, responses
    }
}

// MARK: - AmbitiousParameter
struct AmbitiousParameter: Codable {
    let name, parameterIn: String?
    let schema: Schema2?
    let ref: String?

    enum CodingKeys: String, CodingKey {
        case name
        case parameterIn = "in"
        case schema
        case ref = "$ref"
    }
}

// MARK: - Schema2
struct Schema2: Codable {
    let type: AccountRatingType
    let properties: Properties5
    let schemaRequired: [String]
    let example: HilariousExample

    enum CodingKeys: String, CodingKey {
        case type, properties
        case schemaRequired = "required"
        case example
    }
}

// MARK: - HilariousExample
struct HilariousExample: Codable {
    let items: [FluffyItem]
}

// MARK: - FluffyItem
struct FluffyItem: Codable {
    let mediaType: String
    let mediaID: Int
    let comment: String

    enum CodingKeys: String, CodingKey {
        case mediaType = "media_type"
        case mediaID = "media_id"
        case comment
    }
}

// MARK: - Properties5
struct Properties5: Codable {
    let items: MagentaItems
}

// MARK: - MagentaItems
struct MagentaItems: Codable {
    let type: GenreIDSType
    let items: FriskyItems
}

// MARK: - FriskyItems
struct FriskyItems: Codable {
    let type: AccountRatingType
    let properties: Properties6
    let itemsRequired: [String]

    enum CodingKeys: String, CodingKey {
        case type, properties
        case itemsRequired = "required"
    }
}

// MARK: - Properties6
struct Properties6: Codable {
    let mediaType: SortBy
    let mediaID: MediaID
    let comment: Description

    enum CodingKeys: String, CodingKey {
        case mediaType = "media_type"
        case mediaID = "media_id"
        case comment
    }
}

// MARK: - Responses
struct Responses: Codable {
    let traitStandardErrors401, traitStandardErrors404, traitStandardErrors500: TraitStandardErrors

    enum CodingKeys: String, CodingKey {
        case traitStandardErrors401 = "trait:standardErrors:401"
        case traitStandardErrors404 = "trait:standardErrors:404"
        case traitStandardErrors500 = "trait:standardErrors:500"
    }
}

// MARK: - TraitStandardErrors
struct TraitStandardErrors: Codable {
    let traitStandardErrorsDescription: String
    let schema: TraitStandardErrors401_Schema

    enum CodingKeys: String, CodingKey {
        case traitStandardErrorsDescription = "description"
        case schema
    }
}

// MARK: - TraitStandardErrors401_Schema
struct TraitStandardErrors401_Schema: Codable {
    let type: AccountRatingType
    let properties: AmbitiousProperties
    let schemaRequired: [String]

    enum CodingKeys: String, CodingKey {
        case type, properties
        case schemaRequired = "required"
    }
}

// MARK: - Encode/decode helpers

class JSONNull: Codable, Hashable {

    public static func == (lhs: JSONNull, rhs: JSONNull) -> Bool {
        return true
    }

    public var hashValue: Int {
        return 0
    }

    public init() {}

    public required init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if !container.decodeNil() {
            throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
        }
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encodeNil()
    }
}

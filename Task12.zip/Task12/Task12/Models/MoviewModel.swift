//
//  MoviewModel.swift
//  Task12
//
//  Created by Tushar Ingale on 28/04/22.
//

import Foundation

struct MoviewModel{

    var originalLanguage = ""
    var overview = ""
    var id = 0
    var originalTitle = ""
    var voteAverage = 0.0
    var popularity = 0.0
    var posterPath = " "
    var releaseDate = ""
}


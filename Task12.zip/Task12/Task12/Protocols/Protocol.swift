//
//  Protocol.swift
//  Task12
//
//  Created by Tushar Ingale on 28/04/22.
//

import Foundation

protocol DataTransfer : AnyObject {
    func sendDataToVC(array:[MoviewModel])
}

//
//  Network.swift
//  Task12
//
//  Created by Tushar Ingale on 28/04/22.
//

import Foundation

class NetworkLayer{
    
    var arrayOfMovie = [MoviewModel]()
    var delegateDataTransfer : DataTransfer?
    
   func parseApi(url:String){
        
        guard let urlTask = URL(string: url) else{
            return
        }
        
        let dataTask = URLSession.shared.dataTask(with: urlTask) {(recData,recURLResponse,recError) in
            
          //  print("recData",recData as Any)
          //  print("recURLResponse",recURLResponse as Any)
         //   print("recError",recError as Any)
            if let jsonData = recData{
                
                let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)
              //  print("swagger",welcome?.swagger)
              //  print("paths",welcome?.paths.accountAccountIDMovieRated.accountAccountIDMovieRatedGet.responses)
                guard let responses = welcome?.paths.accountAccountIDMovieRated.accountAccountIDMovieRatedGet.responses else {return }
                for response in responses {
                   //  print("response-->",response)
                    if response.key == "200"{
                      //  print("response-->",response.value)
                        guard let results = response.value.examples?.applicationJSON.results else { return }
                        for result in results {

//                            print("originalLanguage",result.originalLanguage)
//                            print("overview",result.overview)
//                            print("id",result.id)
//                            print("originalTitle",result.originalTitle)
//                            print("voteAverage",result.voteAverage)
//                            print("popularity",result.popularity)
                          
                        //   print("posterPath",posterPath)
//                            print("releaseDate",result.releaseDate)
                            guard let posterPath = result.posterPath else {return}
                            self.arrayOfMovie.append(MoviewModel(originalLanguage: result.originalLanguage.rawValue, overview: result.overview, id: result.id, originalTitle: result.originalTitle, voteAverage: Double(result.voteAverage), popularity: Double(result.popularity), posterPath: posterPath, releaseDate: result.releaseDate))
                        }
                    }
                   
                }
                
            }
            
            DispatchQueue.main.async { [self] in
                self.delegateDataTransfer?.sendDataToVC(array: self.arrayOfMovie)
            }
        }
        dataTask.resume()
    }
    
    
}

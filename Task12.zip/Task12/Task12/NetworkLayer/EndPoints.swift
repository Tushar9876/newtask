//
//  EndPoints.swift
//  Task12
//
//  Created byTushar Ingale on 28/04/22.
//

import Foundation

struct EndPoint{
    
    static var  urlStringOfstoplight = "https://api.stoplight.io/v1/versions/o74HCHnJvtmZWGdMJ/export/oas.json"
}
